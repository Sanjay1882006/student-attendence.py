/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num,var,totle,a;
    a=0;
    printf("enter a number : ");
    scanf("%d",&num);
    var=2;
    while(var!=10)
    {
        totle=num%var;
        if(totle==0)
        {
            printf("%d is not a prime number",num);
            a=1;
            break;
        }
        var++;
    }
    if(a==0)
    {
        printf("%d is a prime number",num);
    }

    return 0;
}

